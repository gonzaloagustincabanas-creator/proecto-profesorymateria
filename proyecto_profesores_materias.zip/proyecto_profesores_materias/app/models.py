from . import get_db

def all_prof(): return [dict(r) for r in get_db().execute('select * from professor')]
def get_prof(id):
    r=get_db().execute('select * from professor where id=?',(id,)).fetchone(); return dict(r) if r else None

def add_prof(a,b,c): db=get_db(); db.execute('insert into professor(name,dedication,category) values(?,?,?)',(a,b,c)); db.commit()
def upd_prof(id,a,b,c): db=get_db(); db.execute('update professor set name=?,dedication=?,category=? where id=?',(a,b,c,id)); db.commit()
def del_prof(id): db=get_db(); db.execute('delete from professor where id=?',(id,)); db.commit()

def all_subj(): return [dict(r) for r in get_db().execute('select * from subject')]
def get_subj(id): r=get_db().execute('select * from subject where id=?',(id,)).fetchone(); return dict(r) if r else None

def add_subj(a,b,c): db=get_db(); db.execute('insert into subject(name,center,hours) values(?,?,?)',(a,b,c)); db.commit()
def upd_subj(id,a,b,c): db=get_db(); db.execute('update subject set name=?,center=?,hours=? where id=?',(a,b,c,id)); db.commit()
def del_subj(id): db=get_db(); db.execute('delete from subject where id=?',(id,)); db.commit()

def subj_by_prof(pid): return [dict(r) for r in get_db().execute('select t.id,s.* from teaching t join subject s on s.id=t.subject_id where t.professor_id=?',(pid,))]
def add_teach(pid,sid): db=get_db(); db.execute('insert or ignore into teaching(professor_id,subject_id) values(?,?)',(pid,sid)); db.commit()
def del_teach(id): db=get_db(); db.execute('delete from teaching where id=?',(id,)); db.commit()
