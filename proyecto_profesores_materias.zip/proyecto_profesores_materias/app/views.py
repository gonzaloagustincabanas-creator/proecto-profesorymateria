from flask import Blueprint,render_template,request,redirect,url_for,flash
from . import models as m
bp=Blueprint('main',__name__)

@bp.route('/')
def i(): return redirect(url_for('main.prof'))

@bp.route('/professors')
def prof(): return render_template('professors.html',items=m.all_prof())

@bp.route('/professors/new',methods=['GET','POST'])
def pnew():
    if request.method=='POST': m.add_prof(request.form['name'],request.form['dedication'],request.form['category']); flash('ok'); return redirect(url_for('main.prof'))
    return render_template('professor_form.html')

@bp.route('/professors/<int:id>/edit',methods=['GET','POST'])
def pedit(id):
    p=m.get_prof(id)
    if request.method=='POST': m.upd_prof(id,request.form['name'],request.form['dedication'],request.form['category']); return redirect(url_for('main.prof'))
    return render_template('professor_form.html',p=p)

@bp.route('/professors/<int:id>/delete',methods=['POST'])
def pdel(id): m.del_prof(id); return redirect(url_for('main.prof'))

@bp.route('/professors/<int:id>',methods=['GET','POST'])
def pdet(id):
    p=m.get_prof(id); subs=m.all_subj()
    if request.method=='POST': m.add_teach(id,int(request.form['subject_id'])); return redirect(url_for('main.pdet',id=id))
    return render_template('professor_detail.html',p=p,teaching=m.subj_by_prof(id),subs=subs)

@bp.route('/subjects')
def subj(): return render_template('subjects.html',items=m.all_subj())

@bp.route('/subjects/new',methods=['GET','POST'])
def snew():
    if request.method=='POST': m.add_subj(request.form['name'],request.form['center'],int(request.form['hours'])); return redirect(url_for('main.subj'))
    return render_template('subject_form.html')

@bp.route('/subjects/<int:id>/edit',methods=['GET','POST'])
def sedit(id):
    s=m.get_subj(id)
    if request.method=='POST': m.upd_subj(id,request.form['name'],request.form['center'],int(request.form['hours'])); return redirect(url_for('main.subj'))
    return render_template('subject_form.html',s=s)

@bp.route('/subjects/<int:id>/delete',methods=['POST'])
def sdel(id): m.del_subj(id); return redirect(url_for('main.subj'))

@bp.route('/teaching/<int:id>/delete',methods=['POST'])
def tdel(id): m.del_teach(id); return redirect(request.referrer or url_for('main.prof'))
