from flask import Flask, g
import sqlite3, os
DB='data.sqlite'

def get_db():
    db=getattr(g,'db',None)
    if db is None:
        path=os.path.join(os.path.abspath(os.path.dirname(__file__)),'..',DB)
        init=not os.path.exists(path)
        db=sqlite3.connect(path); db.row_factory=sqlite3.Row
        g.db=db
        if init: init_db(db)
    return db

def init_db(db):
    c=db.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS professor(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,dedication TEXT,category TEXT);')
    c.execute('CREATE TABLE IF NOT EXISTS subject(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,center TEXT,hours INTEGER);')
    c.execute('CREATE TABLE IF NOT EXISTS teaching(id INTEGER PRIMARY KEY AUTOINCREMENT,professor_id INTEGER,subject_id INTEGER, UNIQUE(professor_id,subject_id));')
    db.commit()

def close_db(e=None): db=getattr(g,'db',None); db and db.close()

def create_app():
    app=Flask(__name__,template_folder='templates')
    app.secret_key='dev'
    app.teardown_appcontext(close_db)
    from . import views
    app.register_blueprint(views.bp)
    with app.app_context(): get_db()
    return app
